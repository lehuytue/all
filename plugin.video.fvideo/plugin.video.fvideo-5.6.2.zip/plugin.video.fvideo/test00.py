import google
import vaphim
import json
import xutils
import xfshare
import unicodedata
import urlfetch
import urllib2
from BeautifulSoup import BeautifulSoup

headers = {
    'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0',
    'Accept-Language': 'en-US,en;q=0.5'
}
str1 = "This be a string"
find_this = "tr"
if find_this in str1:
    print find_this, " is been found in ", str1
else:
    print find_this, " is not found in ", str1
req = urllib2.Request(urllib2.unquote("https://www.fshare.vn/logout"),headers=headers)
f = urllib2.urlopen(req)    
print(BeautifulSoup(f.read(), convertEntities=BeautifulSoup.HTML_ENTITIES))
'''
file = open('thuynga.fvideo','r')
for line in file.readlines():
    list = line.split("##")
    print list[0].encode("utf-8") + "$$$" + list[1].strip()
file.close()
'''
'''
elements = google.search('', 'resident evil', '', 0,50)
print(elements)

data = json.loads(elements)
for ff in data["folders"]:
    print(ff["name"].encode("utf-8") + " : " + ff["href"])
'''
    
#elements = vaphim.getAll("http://vaphim.com/category/collection/")
#print(elements.encode("utf-8"))

#elements = vaphim.getLink("http://vaphim.com/2014/08/20/tom-and-jerry-1940-1948-golden-collection-vol-1/")
'''
elements = vaphim.getLink("http://vaphim.com/2012/01/19/duyen-dang-viet-nam-collections/")
#print(elements.encode("utf-8"))

data = json.loads(elements)
for ff in data["files"]:
    try:
        print(unicodedata.normalize('NFKD', ff["name"]).encode('ascii','ignore') + " ## " + ff["href"])
    except:
        pass
for ff in data["folders"]:
    try:
        print(unicodedata.normalize('NFKD', ff["name"]).encode('ascii','ignore') + " ## " + ff["href"])
    except:
        pass
'''      
        
'''
elements = xfshare.getFileFromFolder("https://www.fshare.vn/folder/QTK9TCD9TY")
print(elements.encode("utf-8"))

data = json.loads(elements)
for ff in data["items"]:
    try:
        print(ff["name"] + " : " + ff["href"])
    except:
        pass
'''
#ck = xutils.doLogin("lesonha@gmail.com","3srh9x")
'''
elements=vaphim.searching("tay")
print(elements.encode("utf-8"))
data = json.loads(elements)
for ff in data["items"]:
    try:
        print(ff["name"].encode("utf-8") + " : " + ff["href"])
    except:
        pass
'''


elements = vaphim.getLink("http://vaphim.com/2016/12/05/diep-vien-tro-lai-end-of-a-gun-2016/")
data = json.loads(elements)
for ff in data["files"]:
    try:
        print(ff["name"].encode("utf-8") + ' - ' + ff["href"])
    except:
        pass
